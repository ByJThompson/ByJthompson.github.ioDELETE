# Learn About Code Splitting
Tutorial for udemy course - Code Splitting
To run the project:

1. Clone this repo
2. Run `npm install`
3. Run `npm start`
